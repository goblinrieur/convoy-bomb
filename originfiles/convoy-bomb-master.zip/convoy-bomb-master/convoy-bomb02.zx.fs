( CONVOY BOMB SCR 2 IS MISSING DUE TO A MISTAKE WHEN COPYING TO 
  RAMDISC IN 1983. ALL BACKUPS FOUND SO FAR ARE WRONG. )        
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                