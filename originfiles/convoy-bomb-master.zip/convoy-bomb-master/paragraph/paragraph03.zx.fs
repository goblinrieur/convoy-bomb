( FORM LOVE LETTER )                                            
0 VARIABLE NAME 12 ALLOT  0 VARIABLE EYES 10 ALLOT              
                                                                
: VITALS  44 TEXT ( ,) PAD NAME 14 CMOVE                        
          44 TEXT      PAD EYES 12 CMOVE                        
           1 TEXT      PAD  ME  14 CMOVE  ;                     
                                                                
: LETTER     CLS                                                
      ." DEAR " NAME 14 -TRAILING TYPE ." ,"                    
   CR ." I GO TO HEAVEN WHENEVER I SEE" CR ." YOUR DEEP "       
                      EYES 12 -TRAILING TYPE ."  EYES. CAN "    
." YOU GO" CR ." TO THE MOVIES FRIDAY? "                        
            CR 15 SPACES ." LOVE,"                              
            CR 15 SPACES ME 14 -TRAILING TYPE                   
   CR ." P.S. WEAR SOMETHING " EYES 12 -TRAILING TYPE           
   ."  TO " CR ." SHOW OFF THOSE EYES. " QUIT ;     ;S          