INTEGRATED          MANAGEMENT          CRITERIA                
TOTAL               ORGANIZATION        FLEXIBILITY             
SYSTEMATIZED        MONITORED           CAPABILITY              
PARALLEL            RECIPROCAL          MOBILITY                
FUNCTIONAL          DIGITAL             PROGRAMMING             
RESPONSIVE          LOGISTICAL          CONCEPTS                
OPTIMAL             TRANSITIONAL        TIME PHASING            
SYNCHRONIZED        INCREMENTAL         PROJECTIONS             
COMPATIBLE          THIRD GENERATION    HARDWARE                
QUALIFIED           POLICY              THROUGH-PUT             
PARTIAL             DECISION            ENGINEERING             
                                                                
;S                                                              
                                                                
                                                                
                                                                