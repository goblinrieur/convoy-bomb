( BUZZPHRASE GENERATOR -- VER. 1)                               
                                                                
( RANDOM NUMBERS SHOULD BE LOADED)                              
                                                                
: BUZZ  311 BLOCK +  11 CHOOSE  64 * +  20 -TRAILING TYPE ;     
: 1ADJ   0 BUZZ ;                                               
: 2ADJ  20 BUZZ ;                                               
: NOUN  40 BUZZ ;                                               
: PHRASE   1ADJ SPACE 2ADJ SPACE NOUN ;                         
: PARAGRAPH                                                     
      CR  ." BY USING " PHRASE ."  COORDINATED WITH "           
      CR  PHRASE  ."  IT IS POSSIBLE FOR EVEN THE MOST "        
      CR  PHRASE  ."  TO FUNCTION AS "                          
      CR  PHRASE  ."  WITHIN THE CONTRAINTS OF "                
      CR  PHRASE  ." . " ;                                      
PARAGRAPH                ;S                                     