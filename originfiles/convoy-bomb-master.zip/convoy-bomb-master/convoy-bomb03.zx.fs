( CONVOY BOMB      83.05.07)                                    
( SKEPP DEF. FORTS. >> ) YS @ 2+ XS @ 5 + PLOT YS @ 1+ XS @ 5 + 
PLOT YS @ XS @ 5 + PLOT YS @ 2+ XS @ 4 + PLOT YS @ 1+ XS @ 4 +  
PLOT YS @ XS @ 4 + PLOT YS @ 2+ XS @ 3 + PLOT YS @ 1+ XS @ 3 + P
LOT YS @ 2+ XS @ 2+ PLOT YS @ 1+ XS @ 2+ PLOT YS @ 2+ XS @ 1+ PL
OT YS @ 2+ XS @ PLOT ;                                          
                                                                
: FLYT -1 XS +! SKEPP YS @ 5 + XS @ 12 + UNPLOT YS @ 4 +        
 XS @ 13 + UNPLOT YS @ 3 + XS @ 13 + UNPLOT YS @ 2+ XS @ 15 +   
UNPLOT YS @ 1+ XS @ 14 + UNPLOT YS @ XS @ 13 + UNPLOT XS @ -14 <
 IF 1 AB +! 64 XS ! THEN ;                                      
: VATTEN HOME 21 0 DO CR LOOP 32 0 DO 23 EMIT LOOP              
 ; : VISA 0 VB ! VATTEN -6 XF ! 2 YS ! 64 XS ! BEGIN 40 YF ! FLY
G FLYT FLYG 16421 @ -577 = UNTIL ;                              
                                                                
-->                                                             